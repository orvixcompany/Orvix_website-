// ORVIX rates file
// -----------------------------------------------------------
// RATE BADALNE KA TAREEQA:
//   Sirf price ke number ko badlein (Rs mein). Jaise price: 2500
//   price: 0 ka matlab hai "Rate WhatsApp par confirm hoga".
//
// PACKAGE KI TAFSEEL (details) LIKHNE KA TAREEQA:
//   details: "Yahan likhein ke package mein kya kya shamil hai"
//   Sirf wahi likhein jo aap sach mein dete hain.
//
// Naya item jodne ke liye kisi ek item ki poori line copy karke
// uske neeche paste karein aur name/price badal dein.
// Quotes " " aur commas , ko jaisa hai waisa rakhein.
// -----------------------------------------------------------

const ORVIX_WHATSAPP = "923242297814";

const ORVIX_SERVICES = [
  {
    id: "cctv",
    name: "CCTV Camera",
    emoji: "📹",
    items: [
      { name: "4 Camera Analog Package", details: "4 analog camera aur 20 meter wire. Baaqi tafseel WhatsApp par confirm hoti hai.", price: 0, unit: "" },
      { name: "8 Camera Analog Package", details: "", price: 0, unit: "" },
      { name: "16 Camera Analog Package", details: "", price: 0, unit: "" },
      { name: "32 Camera Analog Package", details: "", price: 0, unit: "" },
      { name: "4 Camera IP Package", details: "", price: 0, unit: "" },
      { name: "8 Camera IP Package", details: "", price: 0, unit: "" },
      { name: "CCTV Repair & Troubleshooting", details: "", price: 0, unit: "per visit" },
      { name: "DVR / NVR Setup", details: "", price: 0, unit: "per setup" }
    ]
  },
  {
    id: "ac",
    name: "AC Services",
    emoji: "❄️",
    items: [
      { name: "AC Installation", details: "", price: 0, unit: "per AC" },
      { name: "AC Repair", details: "", price: 0, unit: "per visit" },
      { name: "AC Maintenance", details: "", price: 0, unit: "per AC" }
    ]
  },
  {
    id: "geyser",
    name: "Instant Electric Geyser",
    emoji: "🚿",
    items: [
      { name: "Geyser Installation", details: "", price: 0, unit: "per geyser" },
      { name: "Geyser Repair", details: "", price: 0, unit: "per visit" }
    ]
  },
  {
    id: "electrician",
    name: "Electrician",
    emoji: "💡",
    items: [
      { name: "Electrical Fault Checking", details: "", price: 0, unit: "per visit" },
      { name: "Switch / Socket Work", details: "", price: 0, unit: "per piece" },
      { name: "Wiring Work", details: "", price: 0, unit: "per job" }
    ]
  },
  {
    id: "plumber",
    name: "Plumbing",
    emoji: "🔧",
    items: [
      { name: "Plumbing Fault Checking", details: "", price: 0, unit: "per visit" },
      { name: "Tap / Fitting Work", details: "", price: 0, unit: "per piece" },
      { name: "Water Leakage Repair", details: "", price: 0, unit: "per job" }
    ]
  },
  {
    id: "appliances",
    name: "Home Appliances",
    emoji: "🏠",
    items: [
      { name: "Appliance Checking", details: "", price: 0, unit: "per visit" },
      { name: "Appliance Repair", details: "", price: 0, unit: "per job" }
    ]
  },
  {
    id: "laptop",
    name: "Laptop Repair",
    emoji: "💻",
    items: [
      { name: "Laptop Checking / Diagnosis", details: "", price: 0, unit: "per laptop" },
      { name: "Laptop Repair", details: "", price: 0, unit: "per laptop" }
    ]
  },
  {
    id: "carpenter",
    name: "Carpenter",
    emoji: "🪚",
    items: [
      { name: "Carpentry Work", details: "", price: 0, unit: "per job" },
      { name: "Woodwork Fitting", details: "", price: 0, unit: "per job" }
    ]
  },
  {
    id: "painting",
    name: "Painting",
    emoji: "🎨",
    items: [
      { name: "Interior Painting", details: "", price: 0, unit: "per job" },
      { name: "Exterior Painting", details: "", price: 0, unit: "per job" }
    ]
  },
  {
    id: "ceiling",
    name: "Luxury Ceiling",
    emoji: "✨",
    items: [
      { name: "Decorative Ceiling Work", details: "", price: 0, unit: "per job" }
    ]
  }
];
