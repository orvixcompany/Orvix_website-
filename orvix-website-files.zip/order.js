(function () {
  var root = document.getElementById('order-root');
  if (!root || typeof ORVIX_SERVICES === 'undefined') return;

  var only = root.getAttribute('data-service');
  var groups = ORVIX_SERVICES.filter(function (g) { return !only || g.id === only; });
  var multi = groups.length > 1;
  var qty = {};
  var openId = new URLSearchParams(location.search).get('service');

  function money(n) { return 'Rs ' + Number(n).toLocaleString('en-PK'); }
  function priceText(it) {
    return it.price > 0 ? money(it.price) + (it.unit ? ' ' + it.unit : '') : 'Rate WhatsApp par confirm hoga';
  }
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function buildItems(g, parent) {
    g.items.forEach(function (it, i) {
      var key = g.id + '|' + i;
      qty[key] = 0;
      var row = el('div', 'item');
      var info = el('div', 'info');
      info.appendChild(el('div', 'nm', it.name));
      if (it.details) info.appendChild(el('div', 'dt', it.details));
      info.appendChild(el('div', 'pr', priceText(it)));

      var q = el('div', 'qty');
      var minus = el('button', '', '\u2212');
      minus.type = 'button';
      minus.setAttribute('aria-label', 'Kam karein');
      var num = el('span', '', '0');
      var plus = el('button', 'plus', '+');
      plus.type = 'button';
      plus.setAttribute('aria-label', 'Add karein');
      minus.onclick = function () { if (qty[key] > 0) { qty[key]--; num.textContent = qty[key]; update(); } };
      plus.onclick = function () { if (qty[key] < 20) { qty[key]++; num.textContent = qty[key]; update(); } };
      q.appendChild(minus); q.appendChild(num); q.appendChild(plus);

      row.appendChild(info); row.appendChild(q);
      parent.appendChild(row);
    });
  }

  groups.forEach(function (g) {
    if (multi) {
      var d = el('details', 'grp');
      d.id = g.id;
      if (openId === g.id) d.open = true;
      d.appendChild(el('summary', '', g.emoji + ' ' + g.name));
      buildItems(g, d);
      root.appendChild(d);
    } else {
      var box = el('div', 'items');
      buildItems(g, box);
      root.appendChild(box);
    }
  });

  var form = el('div', 'form');
  form.id = 'order-form';
  form.innerHTML =
    '<h3>Aapki details</h3>' +
    '<label for="o-nm">Naam *</label><input id="o-nm" type="text" autocomplete="name" placeholder="Aapka naam">' +
    '<label for="o-ph">Phone number *</label><input id="o-ph" type="tel" autocomplete="tel" placeholder="03xx-xxxxxxx">' +
    '<label for="o-ad">Address / Area (Faisalabad) *</label><textarea id="o-ad" placeholder="Ghar ya dukaan ka address, mohalla ya area"></textarea>' +
    '<label for="o-tm">Kab chahiye? (din / waqt)</label><input id="o-tm" type="text" placeholder="Jaise: kal shaam ya aaj dopahar">' +
    '<label for="o-nt">Koi aur baat (optional)</label><textarea id="o-nt" placeholder="Masle ki detail ya koi khaas hidayat"></textarea>' +
    '<p class="note">Jin services par "Rate WhatsApp par confirm hoga" likha hai, unka final charge WhatsApp par confirm kiya jata hai.</p>';
  root.appendChild(form);

  var bar = el('div', 'bar');
  bar.innerHTML =
    '<div class="in"><div class="sum"><span id="o-cnt"></span><b id="o-tot"></b></div>' +
    '<button class="go" id="o-send" type="button">\uD83D\uDCAC WhatsApp par Order Confirm karein</button>' +
    '<div class="err" id="o-err"></div></div>';
  document.body.appendChild(bar);

  function chosen() {
    var out = [];
    groups.forEach(function (g) {
      g.items.forEach(function (it, i) {
        var n = qty[g.id + '|' + i];
        if (n > 0) out.push({ group: g.name, item: it, n: n });
      });
    });
    return out;
  }

  function update() {
    var c = chosen(), total = 0, unpriced = false, count = 0;
    c.forEach(function (x) {
      count += x.n;
      if (x.item.price > 0) total += x.item.price * x.n; else unpriced = true;
    });
    document.getElementById('o-cnt').textContent = count + (count === 1 ? ' service chuni gayi' : ' services chuni gayin');
    var t = '';
    if (count > 0) {
      if (total > 0) t = money(total) + (unpriced ? ' + baaqi confirm' : '');
      else t = 'Rate confirm hoga';
    }
    document.getElementById('o-tot').textContent = t;
    document.body.classList.toggle('has-bar', count > 0);
    if (count === 0) document.getElementById('o-err').textContent = '';
  }

  function fail(msg, fieldId) {
    document.getElementById('o-err').textContent = msg;
    var f = document.getElementById(fieldId);
    if (f) {
      form.scrollIntoView({ behavior: 'smooth', block: 'start' });
      setTimeout(function () { try { f.focus(); } catch (e) {} }, 400);
    }
  }

  document.getElementById('o-send').onclick = function () {
    document.getElementById('o-err').textContent = '';
    var c = chosen();
    var nm = document.getElementById('o-nm').value.trim();
    var ph = document.getElementById('o-ph').value.trim();
    var ad = document.getElementById('o-ad').value.trim();
    var tm = document.getElementById('o-tm').value.trim();
    var nt = document.getElementById('o-nt').value.trim();

    if (c.length === 0) { fail('Pehle kam az kam ek service chunein.'); return; }
    if (!nm) { fail('Apna naam likhein.', 'o-nm'); return; }
    if (ph.replace(/\D/g, '').length < 10) { fail('Sahi phone number likhein.', 'o-ph'); return; }
    if (!ad) { fail('Apna address ya area likhein.', 'o-ad'); return; }

    var total = 0, unpriced = false;
    var lines = c.map(function (x, i) {
      var line = (i + 1) + '. ' + x.item.name + ' x' + x.n;
      if (x.item.price > 0) { var s = x.item.price * x.n; total += s; line += ' - ' + money(s); }
      else { unpriced = true; line += ' - rate confirm'; }
      return line;
    });

    var page = location.pathname.split('/').pop() || 'home';
    var msg = '*ORVIX - Naya Order*\n\n' +
      'Naam: ' + nm + '\n' +
      'Phone: ' + ph + '\n' +
      'Address: ' + ad + '\n' +
      (tm ? 'Waqt: ' + tm + '\n' : '') +
      '\n*Services:*\n' + lines.join('\n') + '\n\n' +
      (total > 0
        ? 'Total (rate wali services): ' + money(total) + (unpriced ? ' + baaqi confirm\n' : '\n')
        : 'Rate: WhatsApp par confirm karein\n') +
      (nt ? '\nNote: ' + nt + '\n' : '') +
      '\nPage: ' + page;

    location.href = 'https://wa.me/' + ORVIX_WHATSAPP + '?text=' + encodeURIComponent(msg);
  };

  update();
  if (openId && document.getElementById(openId)) {
    setTimeout(function () { document.getElementById(openId).scrollIntoView(); }, 150);
  }
})();
